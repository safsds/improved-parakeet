const menu = {
    list() {
        return [
    {
        "backMenu":[
            {
                "child":[
                    {
                        "buttons":[
                            "查看",
                            "新增",
                            "修改",
                            "报表",
                            "删除"
                        ],
                        "menu":"物资管理",
                        "menuJump":"列表",
                        "tableName":"wuzi"
                    }
                    ,
                    {
                        "buttons":[
                            "查看",
                            "新增",
                            "修改",
                            "审核",
                            "删除"
                        ],
                        "menu":"物资申请管理",
                        "menuJump":"列表",
                        "tableName":"wuziShenqing"
                    }
                ],
                "menu":"物资管理"
            }
        ],
        "frontMenu":[],
        "hasBackLogin":"是",
        "hasBackRegister":"否",
        "hasFrontLogin":"否",
        "hasFrontRegister":"否",
        "roleName":"普通员工",
        "tableName":"laoshi"
    }
]
    }
}
export default menu;
